var mysql = require('./dbconf.js');

function getAllStudents(res) {
    mysql.pool.query("SELECT * FROM Students;", function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.send(results);
        }
    });
}

function getStudentByName(res, name) {
    mysql.pool.query("SELECT * FROM Students WHERE studentName = ?;", [name], function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.send(results);
        }
    });
}

function insertNewStudent(res, name, email, year, major) {
    var sqlQuery = "INSERT INTO Students (studentName, studentEmail, studentYear, studentMajor) VALUES (?, ?, ?, ?);";
    mysql.pool.query(sqlQuery, [name, email, year, major], function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.status(200).send(results.insertId.toString());
        }
    });
}

function updateStudent(res, name, email, year, major, id) {
    var sqlQuery = "UPDATE Students SET studentName = ?, studentEmail = ?, studentYear = ?, studentMajor = ? WHERE studentID = ?;";
    mysql.pool.query(sqlQuery, [name, email, year, major, id], function (error, results, fields) {
        if (error) {
            res.status(400).send(JSON.stringify(error));
        }
        else {
            res.status(200).send(results.insertId.toString());
        }
    });
}

function getAllClasses(res) {
    mysql.pool.query("SELECT * FROM Classes;", function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.send(results);
        }
    });
}

function insertNewClass(res, name, startDate, desc) {
    if (desc == null || desc == "") {
        desc = "NULL";
    }
    var sqlQuery = "INSERT INTO Classes (className, classStartDate, classDescription) VALUES (?, ?, ?);"
    mysql.pool.query(sqlQuery, [name, startDate, desc], function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.status(200).send(results.insertId.toString());
        }
    })
}

function getAllEnrollments(res) {
    mysql.pool.query("SELECT classID, studentID FROM Enrollments;", function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.send(results);
        }
    });
}

function insertNewEnrollments(res, classID, studentID) {
    var sqlQuery = "INSERT INTO Enrollments (classID, studentID) VALUES (?, ?);";
    mysql.pool.query(sqlQuery, [classID, studentID], function (error, results, field) {
        if (error) {
            res.status(400).send();
        }
        else {
            res.status(200).send("Ok");
        }
    });
}

function deleteEnrollment(res, classId, studentId) {
    var sqlQuery = "DELETE FROM Enrollments WHERE classID = ? AND studentID = ?;";
    mysql.pool.query(sqlQuery, [classId, studentId], function (error, results, field) {
        if (error) {
            res.status(400).send();
        }
        else {
            res.status(200).send("Ok");
        }
    });
}

function getAllStudentId(res) {
    mysql.pool.query("SELECT studentID FROM Students;", function (error, results, fields) {
        if (error) {
            res.status(404).send(JSON.stringify(error));
        }
        else {
            res.send(results);
        }
    });
}

function getAllClassId(res) {
    mysql.pool.query("SELECT classID FROM Classes;", function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.send(results);
        }
    });
}

function getAllDepartments(res) {
    mysql.pool.query("SELECT * FROM Departments;", function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.send(results);
        }
    });
}

function insertNewDepartment(res, name, expense, budget, building) {
    if (expense == null || expense == "") {
        expense = null;
    }
    if (budget == null || budget == "") {
        budget = null;
    }
    if (building == null || building == "") {
        building = null;
    }
    var sqlQuery = "INSERT INTO Departments (departmentName, departmentExpenses, departmentBudget, departmentBuilding)" + 
                    "VALUES (?, ?, ?, ?)";
    mysql.pool.query(sqlQuery, [name, expense, budget, building], function (error, results, field) {
        if (error) {
            res.status(400).send();
        }
        else {
            res.send(results.insertId.toString());
        }
    });
}

function getAllBuildingId(res) {
    mysql.pool.query("SELECT buildingID FROM Buildings;", function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.send(results);
        }
    });
}

function getAllEmployees(res) {
    mysql.pool.query("SELECT * FROM Employees;", function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.send(results);
        }
    });
}

function insertNewEmployee(res, name, email, position, password, department) {
    if (department == null || department == "") {
        var sqlQuery = "INSERT INTO Employees (employeeName, employeeEmail, employeePosition, employeePassword)" +
                        "VALUES (?, ?, ?, ?)";
        mysql.pool.query(sqlQuery, [name, email, position, password], function (error, results, field) {
            if (error) {
                console.log(error);
                res.status(400).send(JSON.stringify(error));
            }
            else {
                res.send(results.insertId.toString());
            }
        });
    } else {
        var sqlQuery = "INSERT INTO Employees (employeeName, employeeEmail, employeePosition, employeePassword, employeeDepartment)" +
                        "VALUES (?, ?, ?, ?, ?);";
        mysql.pool.query(sqlQuery, [name, email, position, password, department], function (error, results, field) {
            if (error) {
                console.log(error);
                res.status(400).send(JSON.stringify(error));
            }
            else {
                res.send(results.insertId.toString());
            }
        });
    }
}

function getAllDepartmentId(res) {
    mysql.pool.query("SELECT departmentID FROM Departments;", function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.send(results);
        }
    });
}

function getAllBuildings(res) {
    mysql.pool.query("SELECT * FROM Buildings;", function (error, results, fields) {
        if (error) {
            res.write(JSON.stringify(error));
            res.end();
        }
        else {
            res.send(results);
        }
    });
}

function insertNewBuilding(res, name, addr, numRooms, maxOccupancy) {
    if (maxOccupancy == null || maxOccupancy == "") {
        maxOccupancy = null
    }
    var sqlQuery = "INSERT INTO Buildings (buildingName, address, numberOfRooms, maxOccupancy)" + 
                    "VALUES (?, ?, ?, ?);";
    mysql.pool.query(sqlQuery, [name, addr, numRooms, maxOccupancy], function (error, results, field) {
        if (error) {
            res.status(404).send(JSON.stringify(error));
        }
        else {
            res.send(results.insertId.toString());
        }
    });
}

module.exports = { 
    allStudents: getAllStudents,
    searchStudent: getStudentByName, 
    addStudent: insertNewStudent,
    editStudent: updateStudent,
    allClasses: getAllClasses,
    addClass: insertNewClass, 
    allEnrollments: getAllEnrollments,
    allStudentId: getAllStudentId,
    allClassId: getAllClassId,
    addEnrollment: insertNewEnrollments,
    removeEnrollment: deleteEnrollment,
    allEmployees: getAllEmployees,
    allDempartmentId: getAllDepartmentId,
    addEmmployee: insertNewEmployee,
    allDepartments: getAllDepartments,
    allBuildingId: getAllBuildingId,
    addDepartment: insertNewDepartment,
    allBuildings: getAllBuildings,
    addBuilding: insertNewBuilding
};