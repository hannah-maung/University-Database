const { Router } = require('express');
var express = require('express');
var dbQueries = require('./backend/db')

var app = express();
app.set('port', 3000);

app.use(
    express.urlencoded({
      extended: true
    })
);

app.use(express.json()); 


app.get('/students', function(req, res) {
    dbQueries.allStudents(res);
});
app.post('/studentSearch', function(req, res) {
    dbQueries.searchStudent(res, req.body.name);
});
app.get('/classes', function(req, res) {
    dbQueries.allClasses(res);
});
app.get('/enrollments', function(req, res) {
    dbQueries.allEnrollments(res);
});
app.get('/allStudentId', function (req, res) {
    dbQueries.allStudentId(res);
})
app.get('/allClassId', function (req, res) {
    dbQueries.allClassId(res);
})
app.get('/employees', function(req, res) {
    dbQueries.allEmployees(res);
});
app.get('/allDepartmentId', function(req, res) {
    dbQueries.allDempartmentId(res);
});
app.get('/departments', function(req, res) {
    dbQueries.allDepartments(res);
});
app.get('/allBuildingId', function(req, res) {
    dbQueries.allBuildingId(res);
});
app.get('/buildings', function(req, res) {
    dbQueries.allBuildings(res);
});



app.post('/addClass', function(req, res) {
    dbQueries.addClass(res, req.body.name, req.body.startDate, req.body.desc);
});
app.post('/addStudent', function(req, res) {
    dbQueries.addStudent(res, req.body.name, req.body.email, req.body.year, req.body.major);
});
app.post('/addEnrollment', function(req, res) {
    dbQueries.addEnrollment(res, req.body.classID, req.body.studentID);
});
app.post('/addEmployee', function(req, res) {
    dbQueries.addEmmployee(res, req.body.name, req.body.email, req.body.position, req.body.password, req.body.department);
});
app.post('/addDepartment', function(req, res) {
    dbQueries.addDepartment(res, req.body.name, req.body.expense, req.body.budget, req.body.building);
});
app.post('/addBuilding', function(req, res) {
    dbQueries.addBuilding(res, req.body.name, req.body.addr, req.body.numRooms, req.body.maxOccupancy);
});


app.post('/deleteEnrollment', function (req, res) {
    dbQueries.removeEnrollment(res, req.body.classID, req.body.studentID);
});
app.post('/updateStudent', function(req, res) {
    dbQueries.editStudent(res, req.body.name, req.body.email, req.body.year, req.body.major, req.body.id);
});
app.use(express.static('public'));

//Index
app.get('/',function(req,res){
    res.render('index');
});
app.get('/index',function(req,res){
    res.render('index');
});

app.use(function(req,res){
    res.status(404);
    res.render('404');
});

app.use(function(err, req, res, next){
    console.error(err.stack);
    res.type('plain/text');
    res.status(500);
    res.render('500');
});



// app.get('/', function(request, response){
//     response.sendFile('absolutePathToYour/htmlPage.html');
// });
  
app.listen(app.get('port'), function(){
    console.log('Express started on http://localhost:' + app.get('port') + '; press Ctrl-C to terminate.');
});
