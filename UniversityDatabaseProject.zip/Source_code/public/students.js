function editStudent(e) {
    var nameElem = e.parentElement.parentElement.children[1];
    var textBox = document.createElement("input");
    textBox.setAttribute("type", "text");
    textBox.value = nameElem.innerText;
    nameElem.innerText = "";
    nameElem.appendChild(textBox);

    var emailElem = e.parentElement.parentElement.children[2];
    textBox = document.createElement("input");
    textBox.setAttribute("type", "text");
    textBox.value = emailElem.innerText;
    emailElem.innerText = "";
    emailElem.appendChild(textBox);

    var yearElem = e.parentElement.parentElement.children[3];
    numBox = document.createElement("input");
    numBox.setAttribute("type", "number");
    numBox.setAttribute("min", "1900");
    numBox.setAttribute("max", "3000");
    numBox.setAttribute("onKeyDown", "return false");
    numBox.setAttribute("value", yearElem.innerText);
    yearElem.innerText = "";
    yearElem.appendChild(numBox);

    var majorElem = e.parentElement.parentElement.children[4];
    textBox = document.createElement("input");
    textBox.setAttribute("type", "text");
    textBox.value = majorElem.innerText;
    majorElem.innerText = "";
    majorElem.appendChild(textBox);

    e.innerText = "Save";
    e.setAttribute("onclick", "updateStudent(this)");
}

function updateStudent(e) {
    var idElem = e.parentElement.parentElement.children[0];
    var idValue = idElem.innerText;

    var nameElem = e.parentElement.parentElement.children[1];
    var nameValue = nameElem.children[0].value;
    
    if (nameValue == "" || nameValue == null) {
        alert("Student name cannot be empty");
        return;
    }

    var emailElem = e.parentElement.parentElement.children[2];
    var emailValue = emailElem.children[0].value;

    if (emailValue == "" || emailValue == null) {
        alert("Student email cannot be empty");
        return;
    }

    var yearElem = e.parentElement.parentElement.children[3];
    var yearValue = yearElem.children[0].value;

    if (yearValue == "" || yearValue == null) {
        alert("Student year cannot be empty");
        return;
    }

    var majorElem = e.parentElement.parentElement.children[4];
    var majorValue = majorElem.children[0].value;

    if (majorValue == "" || majorValue == null) {
        alert("Student major cannot be empty");
        return;
    }

    var request = new XMLHttpRequest();
    request.open('POST', '/updateStudent');
    request.setRequestHeader('Content-Type', 'application/json');
    request.addEventListener('load', function (event) {
        if (event.target.status === 200) {
            nameElem.removeChild(nameElem.children[0]);
            nameElem.innerText = nameValue;
            emailElem.removeChild(emailElem.children[0]);
            emailElem.innerText = emailValue;
            yearElem.removeChild(yearElem.children[0]);
            yearElem.innerText = yearValue;
            majorElem.removeChild(majorElem.children[0]);
            majorElem.innerText = majorValue;

            e.innerText = "Edit"
            e.setAttribute("onclick", "editStudent(this)");
        }
        else {
            console.log("Error adding student to db " + event.target.response);
            alert("There was an error with the server please try again.");
        }
    });
    var requestBody = JSON.stringify({
        name: nameValue,
        email: emailValue,
        year: yearValue,
        major: majorValue,
        id: idValue
    });
    request.send(requestBody);
}

function saveStudent(e) {
    var nameElem = e.parentElement.parentElement.children[1];
    var nameValue = nameElem.children[0].value;

    if (nameValue == "" || nameValue == null) {
        alert("Student name cannot be empty");
        return;
    }

    var emailElem = e.parentElement.parentElement.children[2];
    var emailValue = emailElem.children[0].value;

    if (emailValue == "" || emailValue == null) {
        alert("Student email cannot be empty");
        return;
    }

    var yearElem = e.parentElement.parentElement.children[3];
    var yearValue = yearElem.children[0].value;

    if (yearValue == "" || yearValue == null) {
        alert("Student year cannot be empty");
        return;
    }

    var majorElem = e.parentElement.parentElement.children[4];
    var majorValue = majorElem.children[0].value;

    if (majorValue == "" || majorValue == null) {
        alert("Student major cannot be empty");
        return;
    }


    var request = new XMLHttpRequest();
    request.open('POST', '/addStudent');
    request.setRequestHeader('Content-Type', 'application/json');
    request.addEventListener('load', function (event) {
        if (event.target.status === 200) {
            var id = event.target.responseText;
            e.parentElement.parentElement.children[0].innerText = id;

            nameElem.removeChild(nameElem.children[0]);
            nameElem.innerText = nameValue;
            emailElem.removeChild(emailElem.children[0]);
            emailElem.innerText = emailValue;
            yearElem.removeChild(yearElem.children[0]);
            yearElem.innerText = yearValue;
            majorElem.removeChild(majorElem.children[0]);
            majorElem.innerText = majorValue;

            e.innerText = "Edit"
            e.setAttribute("onclick", "editStudent(this)");
        } 
        else {
            console.log("Error adding student to db " + event.target.response);
            alert("There was an error with the server please try again.");
        }
    });
    var requestBody = JSON.stringify({
        name: nameValue,
        email: emailValue,
        year: yearValue,
        major: majorValue
    });
    request.send(requestBody);
}

function addStudent() {
    var table = document.getElementById("tableBody");

    var row = document.createElement("tr");
    var columns = []
    for (var i = 0; i < 6; i++) {
        columns.push(document.createElement("td"));
    }

    var numBox = document.createElement("input");
    numBox.setAttribute("type", "number");
    numBox.setAttribute("min", "1900");
    numBox.setAttribute("max", "3000");
    numBox.setAttribute("onKeyDown", "return false");
    numBox.setAttribute("value", 2021);

    var saveBtn = document.createElement("button");
    saveBtn.innerText = "Save";
    saveBtn.setAttribute("onclick", "saveStudent(this)");
    
    for (var i = 0; i < 6; i++) {
        if (i > 0) {
            if (i == 3) {
                columns[i].appendChild(numBox);
            }
            else if (i == 5) {
                columns[i].appendChild(saveBtn);
            }
            else {
                var textBox = document.createElement("input");
                textBox.setAttribute("type", "text");
                columns[i].appendChild(textBox);
            }
        }
        row.appendChild(columns[i]);
    }

    table.appendChild(row);
}

function searchStudent(e) {
    // disable text box
    e.parentElement.children[1].disabled = true;
    var nameValue = e.parentElement.children[1].value;
    // disable onclick for search button
    e.setAttribute("onclick", "");

    // disable onclick for add button
    document.getElementById("addBtn").setAttribute("onclick", "");

    // remove all rows from table
    //console.log(document.getElementById("tableBody").children);
    var table = document.getElementById("tableBody");
    var tableSize = table.children.length;
    for (var i = 0; i < tableSize; i++) {
        table.removeChild(table.children[table.children.length - 1]);
    }

    // Send request to db and repopulate table with results
    var request = new XMLHttpRequest();
    request.open('POST', '/studentSearch');
    request.setRequestHeader('Content-Type', 'application/json');
    request.addEventListener('load', function (event) {
        if (event.target.status === 200) {
            var data = JSON.parse(event.target.responseText);
            for (var i = 0; i < data.length; i++) {
                var tbody = document.getElementById("tableBody");
                var tr = document.createElement("tr");

                var id = document.createElement("td");
                id.innerText = data[i].studentID;
                tr.appendChild(id);

                var name = document.createElement("td");
                name.innerText = data[i].studentName;
                tr.appendChild(name);

                var email = document.createElement("td");
                email.innerText = data[i].studentEmail;
                tr.appendChild(email);
                
                var year = document.createElement("td");
                year.innerText = data[i].studentYear;
                tr.appendChild(year);

                var major = document.createElement("td");
                major.innerText = data[i].studentMajor;
                tr.appendChild(major);

                var editBtnContainer = document.createElement("td");
                var editBtn = document.createElement("button");
                editBtn.innerText = "Edit";
                editBtn.setAttribute("onclick", "editStudent(this)");
                editBtnContainer.appendChild(editBtn);
                tr.appendChild(editBtnContainer);

                tbody.appendChild(tr);
            }
            e.parentElement.children[1].disabled = false;
            e.setAttribute("onclick", "searchStudent(this)");
            document.getElementById("addBtn").setAttribute("onclick", "addStudent()");
        } 
        else {
            console.log("Error search for student in db " + event.target.response);
            alert("There was an error with the server please try again.");
        }
    });
    var requestBody = JSON.stringify({
        name: nameValue
    });
    request.send(requestBody);
}

function request() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
           //console.log(JSON.parse(xhttp.responseText));
            var data = JSON.parse(xhttp.responseText);
            for (var i = 0; i < data.length; i++) {
                var tbody = document.getElementById("tableBody");
                var tr = document.createElement("tr");

                var id = document.createElement("td");
                id.innerText = data[i].studentID;
                tr.appendChild(id);

                var name = document.createElement("td");
                name.innerText = data[i].studentName;
                tr.appendChild(name);

                var email = document.createElement("td");
                email.innerText = data[i].studentEmail;
                tr.appendChild(email);
                
                var year = document.createElement("td");
                year.innerText = data[i].studentYear;
                tr.appendChild(year);

                var major = document.createElement("td");
                major.innerText = data[i].studentMajor;
                tr.appendChild(major);

                var editBtnContainer = document.createElement("td");
                var editBtn = document.createElement("button");
                editBtn.innerText = "Edit";
                editBtn.setAttribute("onclick", "editStudent(this)");
                editBtnContainer.appendChild(editBtn);
                tr.appendChild(editBtnContainer);

                tbody.appendChild(tr);
            }

            document.getElementById("searchBtn").hidden = false;
            document.getElementById("addBtn").hidden = false;
        }
    };
    xhttp.open("GET", "/students", true);
    xhttp.send();
}

request();