//const { allEnrollments } = require("../backend/db");

function saveEnroll(e) {
    var classElem = e.parentElement.parentElement.children[0];
    var classVal = classElem.children[0].value;

    var studentElem = e.parentElement.parentElement.children[1];
    var studentVal = studentElem.children[0].value;

    var request = new XMLHttpRequest();
    request.open('POST', '/addEnrollment');
    request.setRequestHeader('Content-Type', 'application/json');
    request.addEventListener('load', function (event) {
        if (event.target.status === 200) {
            classElem.removeChild(classElem.children[0]);
            classElem.innerText = classVal;

            studentElem.removeChild(studentElem.children[0]);
            studentElem.innerText = studentVal;

            e.innerText = "Delete"
            e.setAttribute("onclick", "deleteEnroll(this)");
        }
        else {
            alert("There was an error inserting new enrollment. Please try again.")
            var row = e.parentElement.parentElement;
            var body = e.parentElement.parentElement.parentElement;
            body.removeChild(row);
        }
    });
    var requestBody = JSON.stringify({
        classID: classVal,
        studentID: studentVal
    });
    request.send(requestBody);
}

function addEnroll() {
    var table = document.getElementById("tableBody");
    
    var row = document.createElement("tr");
    var columns = []
    for (var i = 0; i < 3; i++) {
        columns.push(document.createElement("td"));
    }

    var saveBtn = document.createElement("button");
    saveBtn.innerText = "Save";
    saveBtn.setAttribute("onclick", "saveEnroll(this)");
    columns[2].appendChild(saveBtn);
    
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var data = JSON.parse(xhttp.responseText);
            var dropDown = document.createElement("select");
            for (var i = 0; i < data.length; i++) {
                var option = document.createElement("option");
                option.innerText = data[i].studentID;
                option.setAttribute("value", data[i].studentID);
                dropDown.appendChild(option);    
            }
            columns[1].appendChild(dropDown);

            var xhttp2 = new XMLHttpRequest();
            xhttp2.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var data2 = JSON.parse(xhttp2.responseText);
                    var dropDown2 = document.createElement("select");
                    for (var i = 0; i < data2.length; i++) {
                        var option = document.createElement("option");
                        option.innerText = data2[i].classID;
                        option.setAttribute("value", data2[i].classID);
                        dropDown2.appendChild(option);    
                    }
                    columns[0].appendChild(dropDown2);

                    row.appendChild(columns[0]);
                    row.appendChild(columns[1]);
                    row.appendChild(columns[2]);
                    table.appendChild(row);
                }
            }
            xhttp2.open("GET", "/allClassId", true);
            xhttp2.send();
        }
    };
    xhttp.open("GET", "/allStudentId", true);
    xhttp.send();
}




function deleteEnroll(e) {

    var row = e.parentElement.parentElement;
    var body = e.parentElement.parentElement.parentElement;
    
    var classElem = e.parentElement.parentElement.children[0];
    var classVal = classElem.innerText;

    var studentElem = e.parentElement.parentElement.children[1];
    var studentVal = studentElem.innerText;

    var request = new XMLHttpRequest();
    request.open("POST", "/deleteEnrollment", true);
    request.setRequestHeader('Content-Type', 'application/json');
    request.addEventListener('load', (event) => { 
        if (event.target.status === 200) {
                body.removeChild(row);
        }
    });

    var requestBody = JSON.stringify({
        classID: classVal,
        studentID: studentVal
    });
    request.send(requestBody);
};


function request() {

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
           //console.log(JSON.parse(xhttp.responseText));
            var data = JSON.parse(xhttp.responseText);
            for (var i = 0; i < data.length; i++) {
                var tbody = document.getElementById("tableBody");
                var tr = document.createElement("tr");

                var id = document.createElement("td");
                id.innerText = data[i].classID;
                tr.appendChild(id);

                var student = document.createElement("td");
                student.innerText = data[i].studentID;
                tr.appendChild(student);

                var editBtnContainer = document.createElement("td");
                var editBtn = document.createElement("button");
                editBtn.innerText = "Delete";
                editBtn.setAttribute("onclick", "deleteEnroll(this)");
                editBtnContainer.appendChild(editBtn);
                tr.appendChild(editBtnContainer);

                tbody.appendChild(tr);
            }


            document.getElementById("addBtn").hidden = false;
        }
    };
    xhttp.open("GET", "/enrollments", true);
    xhttp.send();
}

request();

