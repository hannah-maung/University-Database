function saveBuilding(e) {
    var nameElem = e.parentElement.parentElement.children[1];
    var nameValue = nameElem.children[0].value;

    if (nameValue == null || nameValue == "") {
        alert("Name cannot be empty");
        return;
    }

    var addrElem = e.parentElement.parentElement.children[2];
    var addrValue = addrElem.children[0].value;

    if (addrValue == null || addrValue == "") {
        alert("Address cannot be empty");
        return;
    }

    var numRoomElem = e.parentElement.parentElement.children[3];
    var numRoomValue = numRoomElem.children[0].value;

    if (numRoomValue == null || numRoomValue == "") {
        alert("Number of rooms cannot be empty");
        return;
    }

    var maxOcElem = e.parentElement.parentElement.children[4];
    var maxOcValue = maxOcElem.children[0].value;

    var request = new XMLHttpRequest();
    request.open('POST', '/addBuilding');
    request.setRequestHeader('Content-Type', 'application/json');
    request.addEventListener('load', function (event) {
        if (event.target.status === 200) {
            var id = event.target.responseText;
            e.parentElement.parentElement.children[0].innerText = id;

            nameElem.removeChild(nameElem.children[0]);
            nameElem.innerText = nameValue;

            addrElem.removeChild(addrElem.children[0]);
            addrElem.innerText = addrValue;

            numRoomElem.removeChild(numRoomElem.children[0]);
            numRoomElem.innerText = numRoomValue;

            maxOcElem.removeChild(maxOcElem.children[0]);
            maxOcElem.innerText = maxOcValue;

            e.parentElement.removeChild(e);
        }
        else {
            alert("There was an error inserting new department. Please try again.")
            var row = e.parentElement.parentElement;
            var body = e.parentElement.parentElement.parentElement;
            body.removeChild(row);
        }
    });
    var requestBody = JSON.stringify({
        name: nameValue,
        addr: addrValue,
        numRooms: numRoomValue,
        maxOccupancy: maxOcValue
    });
    request.send(requestBody);
}

function addBuilding() {
    var table = document.getElementById("tableBody");

    var row = document.createElement("tr");
    var columns = []
    for (var i = 0; i < 6; i++) {
        columns.push(document.createElement("td"));
    }

    var saveBtn = document.createElement("button");
    saveBtn.innerText = "Save";
    saveBtn.setAttribute("onclick", "saveBuilding(this)");
   
    var addElem = document.createElement("input");
    addElem.setAttribute("type", "date");
    
    for (var i = 0; i < 6; i++) {
        if (i > 0) {
            if (i == 5) {
                columns[i].appendChild(saveBtn);
            }
            else if (i >= 3 && i <= 4) {
                var numBox = document.createElement("input");
                numBox.setAttribute("type", "number");
                columns[i].appendChild(numBox);
            }
            else {
                var textBox = document.createElement("input");
                textBox.setAttribute("type", "text");
                columns[i].appendChild(textBox);
            }
        }
        row.appendChild(columns[i]);
    }

    table.appendChild(row);
}



function request() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
           //console.log(JSON.parse(xhttp.responseText));
            var data = JSON.parse(xhttp.responseText);
            for (var i = 0; i < data.length; i++) {
                var tbody = document.getElementById("tableBody");
                var tr = document.createElement("tr");

                var id = document.createElement("td");
                id.innerText = data[i].buildingID;
                tr.appendChild(id);

                var name = document.createElement("td");
                name.innerText = data[i].buildingName;
                tr.appendChild(name);

                var address = document.createElement("td");
                address.innerText = data[i].address;
                tr.appendChild(address);
                
                var rooms = document.createElement("td");
                rooms.innerText = data[i].numberOfRooms;
                tr.appendChild(rooms);

                var occupancy = document.createElement("td");
                occupancy.innerText = data[i].maxOccupancy;
                tr.appendChild(occupancy);
              
                var editBtnContainer = document.createElement("td");
                tr.appendChild(editBtnContainer);

                tbody.appendChild(tr);
            }

          
            document.getElementById("addBtn").hidden = false;
        }
    };
    xhttp.open("GET", "/buildings", true);
    xhttp.send();
}

request();