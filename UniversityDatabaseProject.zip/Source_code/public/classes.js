function saveClass(e) {
    var nameElem = e.parentElement.parentElement.children[1];
    var nameVal = nameElem.children[0].value;

    if (nameVal == "" || nameVal == null) {
        alert("Class name cannot be empty");
        return;
    }

    var dateElem = e.parentElement.parentElement.children[2];
    var dateVal = dateElem.children[0].value;

    var descElem = e.parentElement.parentElement.children[3];
    var descVal = descElem.children[0].value;

    var request = new XMLHttpRequest();
    request.open('POST', '/addClass');
    request.setRequestHeader('Content-Type', 'application/json');
    request.addEventListener('load', function (event) {
        if (event.target.status === 200) {
            id = event.target.responseText;
            e.parentElement.parentElement.children[0].innerText = id;

            nameElem.removeChild(nameElem.children[0]);
            nameElem.innerText = nameVal;
            dateElem.removeChild(dateElem.children[0]);
            dateElem.innerText = dateVal;
            descElem.removeChild(descElem.children[0]);
            descElem.innerText = descVal;
            e.parentElement.removeChild(e);
        } 
        else {
            console.log("Error adding class to db " + event.target.response);
            alert("There was an error with the server please try again.");
        }
    });
    var requestBody = JSON.stringify({
        name: nameVal,
        startDate: dateVal,
        desc: descVal
    });
    request.send(requestBody);
}

function addClass(){
    
    var table = document.getElementById("tableBody");

    var row = document.createElement("tr");
    var columns = []
    for (var i = 0; i < 5; i++) {
        columns.push(document.createElement("td"));
    }

    var saveBtn = document.createElement("button");
    saveBtn.innerText = "Save";
    saveBtn.setAttribute("onclick", "saveClass(this)");
   
    var dateBox = document.createElement("input");
    dateBox.setAttribute("type", "date");
    dateBox.value = "2021-01-31";
    
    for (var i = 0; i < 5; i++) {
        if (i > 0) {
            if (i == 2) {
                columns[i].appendChild(dateBox);
            }
            else if (i == 4) {
                columns[i].appendChild(saveBtn);
            }
            else {
                var textBox = document.createElement("input");
                textBox.setAttribute("type", "text");
                columns[i].appendChild(textBox);
            }
        }
        row.appendChild(columns[i]);
    }

    table.appendChild(row);
}



function request() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
           //console.log(JSON.parse(xhttp.responseText));
            var data = JSON.parse(xhttp.responseText);
            console.log(data);
            for (var i = 0; i < data.length; i++) {
                var tbody = document.getElementById("tableBody");
                var tr = document.createElement("tr");

                var id = document.createElement("td");
                id.innerText = data[i].classID;
                tr.appendChild(id);

                var name = document.createElement("td");
                name.innerText = data[i].className;
                tr.appendChild(name);

                var date = document.createElement("td");
                date.innerText = data[i].classStartDate.substring(0, 10);
                tr.appendChild(date);
                
                var description = document.createElement("td");
                description.innerText = data[i].classDescription;
                tr.appendChild(description);

                var editBtnContainer = document.createElement("td");
                tr.appendChild(editBtnContainer);

                tbody.appendChild(tr);
            }
            document.getElementById("addBtn").hidden = false;
        }
    };
    xhttp.open("GET", "/classes", true);
    xhttp.send();
}

request();
