function saveEmployees(e) {
    var nameElem = e.parentElement.parentElement.children[1];
    var nameValue = nameElem.children[0].value;

    if (nameValue == "" || nameValue == null) {
        alert("Name cannot be empty");
        return;
    }

    var emailElem = e.parentElement.parentElement.children[2];
    var emailValue = emailElem.children[0].value;

    if (emailValue == "" || emailValue == null) {
        alert("Email cannot be empty");
        return;
    }

    var positionElem = e.parentElement.parentElement.children[3];
    var positionValue = positionElem.children[0].value;

    if (positionValue == "" || positionValue == null) {
        alert("Position cannot be empty");
        return;
    }

    var passwordElem = e.parentElement.parentElement.children[4];
    var passwordValue = passwordElem.children[0].value;

    if (passwordValue == "" || passwordValue == null) {
        alert("Password cannot be empty");
        return;
    }

    var depElem = e.parentElement.parentElement.children[5];
    var depValue = depElem.children[0].value;

    var request = new XMLHttpRequest();
    request.open('POST', '/addEmployee');
    request.setRequestHeader('Content-Type', 'application/json');
    request.addEventListener('load', function (event) {
        if (event.target.status === 200) {
            var id = event.target.responseText;
            e.parentElement.parentElement.children[0].innerText = id;

            nameElem.removeChild(nameElem.children[0]);
            nameElem.innerText = nameValue;

            emailElem.removeChild(emailElem.children[0]);
            emailElem.innerText = emailValue;

            positionElem.removeChild(positionElem.children[0]);
            positionElem.innerText = positionValue;

            passwordElem.removeChild(passwordElem.children[0]);
            passwordElem.innerText = passwordValue;

            depElem.removeChild(depElem.children[0]);
            depElem.innerText = depValue;

            e.parentElement.removeChild(e);
        }
        else {
            alert("There was an error inserting new employee. Please try again.")
            var row = e.parentElement.parentElement;
            var body = e.parentElement.parentElement.parentElement;
            body.removeChild(row);
        }
    });
    var requestBody = JSON.stringify({
        name: nameValue,
        email: emailValue,
        position: positionValue,
        password: passwordValue,
        department: depValue
    });
    request.send(requestBody);
}

function addEmployees() {
    var table = document.getElementById("tableBody");

    var row = document.createElement("tr");
    var columns = []
    for (var i = 0; i < 7; i++) {
        columns.push(document.createElement("td"));
    }

    var saveBtn = document.createElement("button");
    saveBtn.innerText = "Save";
    saveBtn.setAttribute("onclick", "saveEmployees(this)");
    
    for (var i = 0; i < 5; i++) {
        if (i > 0) {
            var textBox = document.createElement("input");
            textBox.setAttribute("type", "text");
            columns[i].appendChild(textBox);
        }
        row.appendChild(columns[i]);
    }

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var data = JSON.parse(xhttp.responseText);
            var dropDown = document.createElement("select");
            var option2 = document.createElement("option");
            option2.innerText = "";
            option2.setAttribute("value", "");
            dropDown.appendChild(option2);
            for (var i = 0; i < data.length; i++) {
                var option = document.createElement("option");
                option.innerText = data[i].departmentID;
                option.setAttribute("value", data[i].departmentID);
                dropDown.appendChild(option);
            }
            columns[5].appendChild(dropDown);
            columns[6].appendChild(saveBtn);
            row.appendChild(columns[5]);
            row.appendChild(columns[6]);
            table.appendChild(row);
        }
    };
    xhttp.open("GET", "/allDepartmentId", true);
    xhttp.send();
}


function request() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
           //console.log(JSON.parse(xhttp.responseText));
            var data = JSON.parse(xhttp.responseText);
            for (var i = 0; i < data.length; i++) {
                var tbody = document.getElementById("tableBody");
                var tr = document.createElement("tr");

                var id = document.createElement("td");
                id.innerText = data[i].employeeID;
                tr.appendChild(id);

                var name = document.createElement("td");
                name.innerText = data[i].employeeName;
                tr.appendChild(name);

                var email = document.createElement("td");
                email.innerText = data[i].employeeEmail;
                tr.appendChild(email);
                
                var position = document.createElement("td");
                position.innerText = data[i].employeePosition;
                tr.appendChild(position);

                var password = document.createElement("td");
                password.innerText = data[i].employeePassword;
                tr.appendChild(password);

                var department = document.createElement("td");
                department.innerText = data[i].employeeDepartment;
                tr.appendChild(department);

                var editBtnContainer = document.createElement("td");
                var editBtn = document.createElement("button");
                tr.appendChild(editBtnContainer);

                tbody.appendChild(tr);
            }

            document.getElementById("addBtn").hidden = false;
        }
    };
    xhttp.open("GET", "/employees", true);
    xhttp.send();
}

request();




