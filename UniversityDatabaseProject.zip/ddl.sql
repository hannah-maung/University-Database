SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS Enrollments;
DROP TABLE IF EXISTS Students;
DROP TABLE IF EXISTS Departments;
DROP TABLE IF EXISTS Employees;
DROP TABLE IF EXISTS Classes;
DROP TABLE IF EXISTS Buildings;
SET FOREIGN_KEY_CHECKS = 1;

-- Create students table

CREATE TABLE Students(
    studentID INT(11) NOT NULL AUTO_INCREMENT,
    studentName VARCHAR(255) NOT NULL,
    studentEmail VARCHAR(255) NOT NULL,
    studentYear int(11) NOT NULL,
    studentMajor VARCHAR(255) NOT NULL,
    PRIMARY KEY (studentID)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO Students (studentName, studentEmail, studentYear, studentMajor) VALUES
('Mike Tyson' , 'miketyson@adamsuniversity.edu', '2018', 'Communications'),
('Brandon Kai' , 'brandonkai@adamsuniversity.edu', '2019', 'Business'),
('Layla Mai' , 'laylamai@adamsuniversity.edu', '2020', 'Mathematics');

-- Create classes table 

CREATE TABLE Classes (
    classID INT(11) NOT NULL AUTO_INCREMENT,
    className VARCHAR(255) NOT NULL,
    classStartDate DATE,
    classDescription VARCHAR(255),
    PRIMARY KEY(classID)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Add data into classes
INSERT INTO Classes (className, classStartDate, classDescription) VALUES
('Algorithms', '2021-04-01', 'learning the basics of algorithms'),
('Integral Calculus', '2021-04-01', 'learning about integrals'),
('Chemistry 101', '2021-04-01', 'introduction to chemistry');

-- Create buildings table 

CREATE TABLE Buildings (
    buildingID INT(11) NOT NULL AUTO_INCREMENT,
    buildingName VARCHAR(255) NOT NULL,
    address VARCHAR(255) NOT NULL,
    numberOfRooms INT(11) NOT NULL,
    maxOccupancy INT (11),
    PRIMARY KEY (buildingID)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Add data into buildings
INSERT INTO Buildings (buildingName, address, numberOfRooms, maxOccupancy) VALUES
('Tebau Hall', '234 NW 25th st', '52', '500'),
('Stray Hall', '207 NW Grant ave', '48', '1000'),
('Max Hall', '289 NW 25th st', '34', '500');

-- Create departments table
CREATE TABLE Departments(
    departmentID INT(11) NOT NULL AUTO_INCREMENT,
    departmentName VARCHAR(255) NOT NULL,
    departmentExpenses DECIMAL (10,2),
    departmentBudget DECIMAL (10,2),
    departmentBuilding INT(11),
    PRIMARY KEY(departmentID),
    FOREIGN KEY(departmentBuilding) REFERENCES Buildings (buildingID)
    ON UPDATE CASCADE
    ON DELETE SET NULL
	
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Create employees table

CREATE TABLE Employees (
    employeeID INT(11) NOT NULL AUTO_INCREMENT,
    employeeName VARCHAR(255) NOT NULL,
    employeeEmail VARCHAR(255) NOT NULL,
    employeePosition VARCHAR(255) NOT NULL,
    employeePassword VARCHAR(255) NOT NULL,
    employeeDepartment INT(11),
    PRIMARY KEY(employeeID),
    FOREIGN KEY(employeeDepartment) REFERENCES Departments (departmentID)
    ON UPDATE CASCADE
    ON DELETE SET NULL
)ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Create Enrollments table

CREATE TABLE Enrollments (
    enrollmentID INT(11) NOT NULL AUTO_INCREMENT,
    classID INT(11) NOT NULL,
    studentID INT(11) NOT NULL,
    PRIMARY KEY (enrollmentID),
    FOREIGN KEY(classID) REFERENCES Classes (classID)
    ON UPDATE CASCADE
    ON DELETE CASCADE,
    FOREIGN KEY (studentID) REFERENCES Students (studentID)
    ON UPDATE CASCADE
    ON DELETE CASCADE

)ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- Add data into departments 
INSERT INTO Departments (departmentName, departmentExpenses, departmentBudget, departmentBuilding) VALUES
('Chemistry','12500.00','17000.00', '1'),
('Acccounting','11200.00','15000.00', '2'),
('Biology','10030.00','16000.00', '3');

-- Add data into employees
INSERT INTO Employees (employeeName, employeeEmail, employeePosition, employeePassword,employeeDepartment) VALUES 
('Lisa Smith', 'lisasmith@adamsuniversity.edu', 'Professor', 'password1', '1'),
('Anthony Kins', 'anthonykins@adamsuniversity.edu', 'Professor', 'password2', '2'),
('Chris Hayes', 'chrishayes@adamsuniversity.edu', 'Professor', 'password3', '3');


INSERT INTO Enrollments (classID, studentID) VALUES
('1','3'),
('2','3'),
('1','2');

