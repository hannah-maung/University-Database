--- Students table
---==================================================================
--- Insert new students
INSERT INTO Students
(studentName, studentEmail, studentYear, studentMajor)
VALUES (:nameInput, :emailInput, :yearInput, :majorInput);

--- Update student
UPDATE Students
SET studentName = :nameInput,
studentEmail = :emailInput,
studentYear = :yearInput,
studentMajor = :majorInput
WHERE studentID = :idInput;

--- Search for student
SELECT * FROM Students
WHERE studentName = :nameInput;

--- Display all students
SELECT * FROM Students;
---===================================================================

--- Classes table
---===================================================================
--- Insert new classes
INSERT INTO Classes
(className, classStartDate, classDescription)
VALUES (:nameInput, :startDateInput, :descriptionInput);

--- Display all classes
SELECT * FROM Classes;
---===================================================================

--- Enrollments table
---===================================================================
--- Insert new enrollments
INSERT INTO Enrollments
(classID, studentID)
VALUES (:classIDInput, :studentIDInput);

--- Delete enrollment
DELETE FROM Enrollments
WHERE classID = :classIDInput AND studentID = :studentIDInput;

--- Display all enrollments
SELECT * FROM Enrollments;

--- Get all student ID
SELECT studentID FROM Students;

--- Get all class ID
SELECT classID FROM Classes;
---===================================================================

--- Departments table
---===================================================================
--- Insert new departments
INSERT INTO Departments
(departmentName, departmentExpenses, departmentBudget, departmentBuilding)
VALUES (:nameInput, :expenseInput, :budgetInput, :buildingInput);

--- Display all departments
SELECT * FROM Departments;

--- Get all building id
SELECT buildingID FROM Buildings;
---====================================================================

--- Employees table
---====================================================================
--- Insert new employees
INSERT INTO Employees
(employeeName, employeeEmail, employeePosition, employeePassword, employeeDepartment)
VALUES (:nameInput, :emailInput, :positionInput, :passInput, :departmentInput);

--- Display all employees
SELECT * FROM Employees;

--- Get all department id;
SELECT departmentID FROM Departments;
---====================================================================

--- Buildings table
---====================================================================
--- Insert new buildings
INSERT INTO Buildings
(buildingName, address, numberOfRooms, maxOccupancy)
VALUES (:nameInput, :addressInput, :numRoomsInput, :maxOccupancyInput);

--- Display all buildings
SELECT * FROM Buildings;
